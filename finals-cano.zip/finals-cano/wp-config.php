<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'finalsCano' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'TTfGsxPliZe_OiM+aqX<,l!,s},3K1lrv/j:[W.1LzJ=EHD1Fd6;Eygb]<4mO]iL' );
define( 'SECURE_AUTH_KEY',  'Ie bTaR%h[!3]mcP+~A/|Kq>K+DHlltj1/wOMg#[TF:yU.Hb.LQ|g8<f,5l5zM5E' );
define( 'LOGGED_IN_KEY',    'j}3d=^/5Rk(32Qb~j.TaV=OC&uy3dYhS44=b6uz-Iz^yvEbN,;~YmsOlzxK?D:1*' );
define( 'NONCE_KEY',        'ReEr!e41bCCs9S:n)i#iP~FnUDp*diMF(2M`v4gEO3_5jhle`s_h]@q+XbJ$~#o!' );
define( 'AUTH_SALT',        ']dnyoObGS?6qs@7}_M:m&E;+aOi)c9gBe;*Xo| sk|ican1:N`M>|f[2hC@;u=>D' );
define( 'SECURE_AUTH_SALT', '3 A(eZ{lma!tDI*>ygb]:g=4`~^H1f@h<jUa?|:pBR^dYs{&P4$PGMg5<t(AKhxz' );
define( 'LOGGED_IN_SALT',   '?x1`Usr;%H*}JzHQ,z-0DNgAR=0m h;K0v?UZj!94ms{2WLL_suvPboxss_qiTF<' );
define( 'NONCE_SALT',       '.>wRq?U>8:D>*zZcyt:u]J|.#d$%J/Y;;n,l6u?F`9 q?sj s@MpDA9J1MK*YoMr' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
